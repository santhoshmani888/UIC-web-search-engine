# -*- coding: utf-8 -*-
"""
Created on Sat May  4 03:15:26 2019

@author: santh
"""

#name:Santhosh mani
#uin: 662957954

#importing library

import time, re, os, pickle, requests
import glob
import json



from urllib.parse import urlparse
from bs4 import BeautifulSoup

from collections import deque


import string
import nltk

from urllib.parse import urljoin, urlparse
from urllib.request import urlopen


from nltk.stem import PorterStemmer



from nltk.corpus import stopwords
stopwords = list(set(stopwords.words('english')))


def stemmer_porter(a):  # function to apply stemming on the words
    stemmer = PorterStemmer()
    a = [stemmer.stem(i) for i in a]
    return a



def parse(url, response, base, word_count, vocabulory):
    soup = BeautifulSoup(response, 'lxml')
    content = None
    if soup.body:
        p_tags_content = soup.findAll('p')
        p_tags_content = [tag.text for tag in p_tags_content]
        span_tags_content = soup.findAll('span')
        span_tags_content = [tag.text for tag in span_tags_content]
        h_tags_content = soup.findAll('h')
        h_tags_content = [tag.text for tag in h_tags_content]
        
        text = ' '.join(p_tags_content) + ' ' + ' '.join(span_tags_content) + ' ' + ' '.join(h_tags_content)
        spider[url] = {'text': text}
        
        content = clean(url,soup, response)
        
        content = tokenize_text(content, word_count, vocabulory, url)
    links = [urljoin(url, l.get('href')) for l in soup.findAll('a')]
    links = [l.rstrip("/") for l in links if urlparse(l).netloc in base]
    return url, content, list(set(links))


def tokenize_text(content, word_count, vocabulory, url):
	arr = []
	vocab = True
	translator=str.maketrans('','',string.punctuation)
	
	cleanr = re.compile('<.*?>')
	content = re.sub(cleanr, '', content)
	content = ''.join([i for i in content if not i.isdigit()])
	content = content.strip().lower()
	content = content.translate(translator)
	words = nltk.word_tokenize(content)  # tokenize the words using nltk's tokenizer
	words = [i for i in words if not i in stopwords] # remove stop words
	words = stemmer_porter(words) # stemming
	words = [i for i in words if not i in stopwords] # remove stop words after stemming
	word_count[url] = {}
	for token in words:
		if len(token) > 2: # use the word only if the length is greater than 2
			if token not in word_count[url].keys():
				word_count[url][token] = 1
			else:
				word_count[url][token] += 1
			
			if token not in vocabulory:
				vocabulory[token] = 1
			elif vocab:
				vocabulory[token] += 1
				vocab = False
			arr.append(token)
	return arr

def clean(url,soup, html):
    for script in soup(["script", "style"]): # remove all javascript and stylesheet code
        script.extract()
    # get text
    text = soup.get_text()
    
    
    # break into lines and remove leading and trailing space on each
    lines = (line.strip() for line in text.splitlines())
    # break multi-headlines into a line each
    chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
    # drop blank lines
    text = '\n'.join(chunk for chunk in chunks if chunk)
    return text

def open_pickle(name):
    with open(name, 'rb') as f:
        return pickle.load(f)



def save_pickle(filename,obj):
    with open(filename, 'wb') as f:
        pickle.dump(obj, f, pickle.HIGHEST_PROTOCOL)
    

    
        
    
def data_crawl(webLinks):
    for k, v in webLinks.items():
        try:
            response = urlopen("http://"+v)
        except Exception as e:
            print(e, v)
            continue
        base = [urlparse(u).netloc for u in v]
        data = parse(v, response, base, word_count, vocabulory)
        if data is not -1:
            crawled[v] = data
    return crawled
       


if __name__=="__main__":
    spider={}
    path=os.getcwd()
    flag=True
 
    if os.path.isfile('crawled_pages.pkl')and os.path.isfile('word_count.pkl') and os.path.isfile('vocabulory.pkl'):
        
        crawled = open_pickle('crawled_pages.pkl')

        word_count = open_pickle("word_count.pkl")
        vocabulory = open_pickle("vocabulory.pkl")
    else:
        
        pagesCount = 5000
        MainUrl = "https://www.cs.uic.edu/"

        pageNo = 0
        urlQueue = deque()
        webLinks = {}



        word_count = {}
        vocabulory = {}
        crawled = {}
        not_allowed = ['mailto:', 'favicon', '.ico', '.css', '.js','.jpg', '.jpeg', '.png', '.gif', '.pdf', '.doc','.JPG', '.mp4', '.svg']

        include_content = "uic.edu"
        regexp = re.compile(
        r'^(?:http|ftp)s?://'
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|' #domain...
        r'localhost|' 
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})' # ip
        r'(?::\d+)?' # port
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)
        exclude_content = ['mailto:', 'favicon', '.ico', '.css', '.js',
                                '.jpg', '.jpeg', '.png', '.gif', '.pdf', '.doc',
                                '.JPG', '.mp4', '.svg']

        o = urlparse(MainUrl)
        urlQueue.append((o.netloc).lstrip("www."))
        while(len(urlQueue) != 0):
            try:
                Url = urlQueue.popleft()
                r = requests.get("http://"+Url)
                if(r.status_code == 200):
                    webLinks[pageNo] = Url


                    soup = BeautifulSoup(r.text, 'lxml')
                    tags = soup.find_all('a')
                    for tag in tags:
                        try: 
                            if(re.match(regexp, tag["href"]) is not None and not any(word in tag["href"] for word in exclude_content)):
                                o = urlparse(tag["href"])
                                temp_href = ((o.netloc+o.path).lstrip("www.").rstrip("/"))
                                if(include_content in tag["href"] and temp_href not in webLinks.values() and temp_href not in urlQueue):
                                    urlQueue.append(temp_href)
                        except:
                            continue



                    pageNo += 1
                    if pageNo>pagesCount:
                        print(pageNo)
                        break
            except Exception as e:
                print(e)
                print("Connection failed for ", Url)
                time.sleep(5)
                continue

        crawled=data_crawl(webLinks)

        save_pickle('crawled_pages.pkl',crawled)
        save_pickle('word_count.pkl',word_count)
        save_pickle('vocabulory.pkl',vocabulory)
        with open('spider.pkl', 'wb') as f:
            pickle.dump(spider,f)
        

    