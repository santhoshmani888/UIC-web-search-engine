# -*- coding: utf-8 -*-
"""
Created on Sun May  5 15:40:12 2019

@author: santh
"""
#santhosh mani
#uin:662957954

import easygui as eg
import nltk
from nltk.stem import PorterStemmer
import json
import sys
import os

import re
from nltk.corpus import stopwords


main_stop_words = list(set(stopwords.words('english')))+["recommend","Copyright","Privacy","Statement","Board","trustees","IE11","Firefox","Chrome","Safari"]



import math
from collections import defaultdict

import re as reg
from nltk.corpus import stopwords
import os
import pickle

tot_length = {}
doc_freq = defaultdict(int)
idx_file ={}
spider = {}
main_stop_words = list(set(stopwords.words('english')))+["recommend","Copyright","Privacy","Statement","Board","trustees","IE11","Firefox","Chrome","Safari"]


def get_spider():
    return spider


def get_idf(df):
    N = len(spider)
    return math.log2(N/df)


def construct_documnet_frequeny(doc_freq, valid_nodes):

    for node in list(set(valid_nodes)):
        doc_freq[node] += 1
    return doc_freq


def get_document_term_frequencies(valid_nodes):

    tf_dict = defaultdict(int)
    for node in valid_nodes:
        tf_dict[node.split('_')[0]] += 1
    return tf_dict


def compute_tf_idf_score(spider, doc_freq):

    for document_name in spider.keys():
        token_list = spider[document_name]['term_frequecy_vector'].keys()
        tf_dict_for_doc = spider[document_name]['term_frequecy_vector']
        tf_idf_dict_for_doc = defaultdict(int)
        for token in token_list:
            for word in token.split():
                tf_idf_dict_for_doc[token] += tf_dict_for_doc[word] * get_idf(doc_freq[word])

        spider[document_name]['tf_idf_vector'] = tf_idf_dict_for_doc
    return spider

def word_without_punctuations(word):
    refined_word = reg.sub('[^a-zA-Z]+', '', word)
    refined_word = refined_word.lower().strip()
    return refined_word

def refine_token(token):
    stemmer = PorterStemmer()
    refined_token = word_without_punctuations(token)

    #stopwords = get_stopwords()
    if refined_token in main_stop_words:
        return ''
    refined_token = stemmer.stem(refined_token)
    if refined_token not in main_stop_words and len(refined_token)>=2:
        #print(refined_token)
        return refined_token
    else:
        return ''

def tokenize_data_for_valid_nodes(word_list):

    collection_tokens = []

    for word in word_list:
        word_formatted = refine_token(word)
        if word_formatted != '':
            collection_tokens.append(word_formatted)
    return collection_tokens


def run_vectorizer():
    for doc in spider.keys():
        data = spider[doc]['text']
        tokens = tokenize_data_for_valid_nodes(data.split())
        spider[doc]['vector'] = tokens
        construct_documnet_frequeny(doc_freq, tokens)
        term_frequency_dict = get_document_term_frequencies(tokens)
        spider[doc]['tf_idf_vector'] = term_frequency_dict
        update_index_file(term_frequency_dict, doc)

    pass


def update_index_file(word_formatted, doc_id):

    for word in word_formatted.keys():
        if word in idx_file:
            idx_file[word][doc_id] = word_formatted[word]
        else:
            idx_file[word] = {doc_id:word_formatted[word]}


def get_tf_dict_for_query(ref_query_tokens):
    tf_dict_for_query = {}
    for token in ref_query_tokens:
        if token not in tf_dict_for_query:
            tf_dict_for_query[token] = 1
        else:
            tf_dict_for_query[token] += 1
        #print(tf_dict_for_query,token)
    return tf_dict_for_query


def pre_compute_document_lengths():
    for doc_id in spider.keys():
        doc_length = 0
        doc_words_list = spider[doc_id]['tf_idf_vector']
        for word in doc_words_list:
            idf = get_idf(doc_freq[word])
            weight = idx_file[word][doc_id] * idf
            weight = weight * weight
            doc_length += weight
        tot_length[doc_id] = doc_length


def get_query_length(tf_dict_for_query):
    query_length = 0
    for q_token, qtf in tf_dict_for_query.items():
        if q_token in idx_file:
            weight = qtf * get_idf(doc_freq[q_token])
            weight = weight * weight
            query_length += weight
    query_length = math.sqrt(query_length)
    return query_length


def get_document_length(doc_id):
    return tot_length[doc_id]


def compute_cosine_sim(ref_query_tokens, doc_id):
    tf_dict_for_query = get_tf_dict_for_query(ref_query_tokens)
    #print(tf_dict_for_query)
    numerator = 0
    for q_token, qtf in tf_dict_for_query.items():
        if q_token in idx_file:
            if doc_id in idx_file[q_token]:
                idf = get_idf(doc_freq[q_token])
                query_weight_for_word = qtf * idf
                doc_weight_for_word = idx_file[q_token][doc_id] * idf
                numerator += query_weight_for_word * doc_weight_for_word

    query_length = get_query_length(tf_dict_for_query)
    doc_length = get_document_length(doc_id)

    doc_length = math.sqrt(doc_length)
    denominator = query_length * doc_length
    similarity = 0
    if denominator != 0:
        similarity = numerator/denominator
    return similarity


def tfidfranker():
    global spider
    
    if os.path.isfile('Spider.pkl'):
        with open('Spider.pkl','rb') as f:
            spider=pickle.load(f)
            run_vectorizer()
            pre_compute_document_lengths()
            print("TF-IDF vector constructed")
    return



def stemmer_porter(arr):  # function to apply stemming on the words
    stemmer = PorterStemmer()
    arr = [stemmer.stem(i) for i in arr]
    return arr

def score(pageranks, query):
	prob_query = {}
	ranks = {}
	query = nltk.word_tokenize(query)
	query = stemmer_porter(query)
	for word in query:
		prob_query[word] = 1/len(query)
	for doc in pageranks:
		ranks[doc] = sum(prob_query[word]*pageranks[doc][word] if word in pageranks[doc] else 0 for word in query)
	return ranks

def return_links_tfidf(ranks,more_results):
    if more_results:
        top = 20
    else:
        top = 10
    results = ranks[0:top]
    return results

def return_links(ranks,more_results):
    if more_results:
        top = 20
    else:
        top = 10
    results = sorted(ranks.items(), key=lambda x: (-x[1], x[0]))[0:top]
    return results

def main_menu():
    choice = display_main_menu()
    execute_function(choice)
    
def exit_engine():
    
    exit


def get_input(msg, title):
    text = eg.enterbox(msg, title)
    if text is None:
        exit_engine()
    
    return text

def display_main_menu():
    
    msg ="                               Query on UIC                                             "
    
    title = "UIC search"
    choices = ["search", "Exit search engine"]
    choice = eg.buttonbox(msg, title, choices=choices)
    return choice

def load_json(name):
	with open(name+'.json') as json_data:
		return json.load(json_data)


def execute_function(main_menu_choice):
    switcher = {
        
        'search': search,
        'Exit search engine': exit_engine,
    }
    # Get the function from switcher dictionary
    func = switcher.get(main_menu_choice, lambda: "nothing")
    return func()
def word_punctuations(word):
    refined_word = re.sub('[^a-zA-Z]+', '', word)
    refined_word = refined_word.lower().strip()
    return refined_word

def clean_token(token):
    stemmer = PorterStemmer()
    refined_token = word_punctuations(token)

    #stopwords = get_stopwords()
    if refined_token in main_stop_words:
        return ''
    refined_token = stemmer.stem(refined_token)
    if refined_token not in main_stop_words and len(refined_token)>=2:
        #print(refined_token)
        return refined_token
    else:
        return ''


def execute_query_v2(query):
        query_tokens = query.split()
        
        refined_query_tokens = [clean_token(i) for i in query_tokens]
        docs_for_query = retrieve_docs_for_query_v2(refined_query_tokens)
        sorted_similarity = sorted(docs_for_query, key=docs_for_query.get, reverse=True)
        sorted_similarity=sorted_similarity[:30]
        #print(docs_for_query)
        return sorted_similarity
def retrieve_docs_for_query_v2(ref_query_tokens):
        spider = get_spider()
        doc_weights = {}
        for doc in spider:
            #print(ref_query_tokens, doc)
            doc_weights[doc] = compute_cosine_sim(ref_query_tokens, doc)
        return doc_weights

def search():
    msg ="                                      Query on UIC                                             "
    
    title = "UIC search"
    text=get_input(msg, title)
    if text is None:
        exit_engine()
    query_tokens = text
    
    
    tfrank=execute_query_v2(query_tokens)
    #print(tfrank)
    tfidfrank=["SHOW MORE RESULTS"]+tfrank
    #tfidfrank=tfidfrank[:10]
    ranks = score(pageranks, text)
    
    more_results=False
    results = return_links(ranks,more_results)
    r=[i[0] for i in results]
    
    r=["SHOW MORE RESULTS"]+r
    
    msg="Choose search method"
    title="UIC Search"
    choices = ["Querydependent-pagerank", "tfidf"]
    choice = eg.buttonbox(msg, title, choices=choices)
    if choice!="tfidf":
        msg = "query: "+str(text)+"\nPagerank Top 10 results of your query"
        x=eg.choicebox(msg, "SearchEngine results", r)
        
        if x=="SHOW MORE RESULTS":
            eg.msgbox(msg="You chose Show more results")
            more_results=True
            results = return_links(ranks,more_results)
            r=[i[0] for i in results]
            msg = "query: "+str(text)+"\nThese are the results of your query"
            l=eg.choicebox(msg, "SearchEngine results", r)
            if l:
                choice=display_main_menu()
                execute_function(choice)
                
            
        if x!="SHOW MORE RESULTS":
            choice=display_main_menu()
            execute_function(choice)
    else:
        msg = "query: "+str(text)+"\nTFIDF Top 10 results of your query"
        x=eg.choicebox(msg, "SearchEngine results", tfidfrank[:10])
        
        if x=="SHOW MORE RESULTS":
            eg.msgbox(msg="You chose Show more results")
            more_results=True
            results = return_links_tfidf(tfrank,more_results)
            
            
            msg = "query: "+str(text)+"\nThese are the results of your query"
            l=eg.choicebox(msg, "SearchEngine results", results)
            if l:
                choice=display_main_menu()
                execute_function(choice)
                
            
        if x!="SHOW MORE RESULTS":
            choice=display_main_menu()
            execute_function(choice)
        
    
    return True

if __name__=="__main__":
    if len(sys.argv)==2:
        path=sys.argv[1]
        os.chdir(path)
    
    
    tfidfranker()
    print("Loading Page Rank....")
    
    pageranks = load_json("querydependentrank")
    main_menu()
            
    